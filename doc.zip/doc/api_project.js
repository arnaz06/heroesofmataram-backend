define({
  "name": "Heroes of Mataram",
  "version": "0.1.0",
  "description": "Dokumentasi API Heroes Of Mataram",
  "title": " Heroes Of Mataram",
  "url": "http://localhost:3000/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-12-20T07:46:57.773Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
